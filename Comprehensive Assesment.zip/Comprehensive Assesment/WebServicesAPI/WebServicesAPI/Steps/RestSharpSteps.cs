﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using WebServicesAPI.Model;

namespace WebServicesAPI.Steps
{
    [Binding]
    public class RestSharpSteps
    {
        private readonly string baseUrl = "https://be-java.azurewebsites.net/api/v1/";

        [Given(@"The endpoint of url is (.*)")]
        public void GivenTheEndpointOfUrlIs(string endPoint)
        {
            APIHelper.InitializeClient(baseUrl, endPoint);
        }

        [Given(@"I create a (.*) request")]
        public void GivenICreateARequest(Method method)
        {
            APIHelper.CreateRequest(method);
        }

        [Given(@"I pass the url parameter as (.*)")]
        public void GivenIPassTheUrlParameterAs(string urlParam)
        {
            APIHelper.AddUrlParameter(urlParam);
        }


        [When(@"I send the request")]
        public void WhenISendTheRequest()
        {
            APIHelper.Execute();
        }

        [Given(@"I add the request body using the below params")]
        public void GivenIAddTheRequestBody(Table table)
        {
            var requestBody = table.CreateInstance<EmployeeDTO>();
            string reqJsonBody = JsonConvert.SerializeObject(requestBody); //converting obj to json string
            APIHelper.AddRequestBody(reqJsonBody);
        }


        [Then(@"I check the details")]
        public void ThenICheckTheDetails()
        {
            APIHelper.displaydetails();
        }

        [Then(@"I validate the status code (.*)")]
        public void ThenIValidateTheStatusCode(string status)
        {
            APIHelper.ValidateResponse(status);
        }

        [Given(@"I add the request body for multiple emp using the below params")]
        public void GivenIAddTheRequestBodyUsingTheBelowParamsf(Table table)
        {
            dynamic emp = table.CreateSet<EmployeeDTO>();
            string reqJsonBody = JsonConvert.SerializeObject(emp); //converting obj to json string
            APIHelper.AddRequestBody(reqJsonBody);

        }

    }
}
