﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace WebServicesAPI
{
    class APIHelper
    {
        private static IRestClient client;
        private static IRestRequest request;
        static IRestResponse response;

        internal static void InitializeClient(string baseurl, string endpoint)
        {
            string url = Path.Combine(baseurl + endpoint);
            client = new RestClient(url);
        }

        internal static void CreateRequest(Method methodName)
        {
            request = new RestRequest(methodName);
        }

        internal static void AddUrlParameter(string urlparam)
        {
            request.AddUrlSegment("id", urlparam);
        }

        internal static void Execute()
        {
            response = client.Execute(request);

        }

        internal static void displaydetails()
        {
            dynamic responseContent = JsonConvert.DeserializeObject(response.Content);
            Console.WriteLine(responseContent);
        }

        internal static void AddRequestBody(string jsonrequestbody)
        {
            request.AddJsonBody(jsonrequestbody);

        }

        internal static void ValidateResponse(string expectedStatusDes)
        {
            string actualStatus = response.StatusCode.ToString();
            Assert.AreEqual(expectedStatusDes, actualStatus, "The status code mismatch");

           //Console.WriteLine((int)response.StatusCode);

        }
    }
}
