﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebServicesAPI.Model
{
    public class EmployeeDTO
    {
        public string compitency { get; set; }
        public Int32 id { get; set; }
        public string name { get; set; }
        public Int32 yearOfJoining { get; set; }
    }
}
