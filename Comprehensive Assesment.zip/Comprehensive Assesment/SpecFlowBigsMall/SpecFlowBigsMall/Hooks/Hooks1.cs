﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using OpenQA.Selenium;
using System;
using System.IO;
using TechTalk.SpecFlow;

namespace SpecFlowBigsMall.Hooks
{
    [Binding]
    public sealed class Hooks1
    {
        public IWebDriver driver;
       
        [BeforeScenario]
        public void BeforeScenario()
        {
            Console.WriteLine("Before Scenario");
        }

        [AfterScenario]
        public void AfterScenario()
        {
            BrowserFactory.takeScreenshot();
            BrowserFactory.close();
        }
    }
}


