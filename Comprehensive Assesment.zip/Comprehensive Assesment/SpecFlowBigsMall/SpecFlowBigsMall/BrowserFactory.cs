﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Threading;

namespace SpecFlowBigsMall
{
    internal class BrowserFactory
    {
        public static IWebDriver driver;

        public BrowserFactory(IWebDriver _driver)
        {
            driver = _driver;
        }

        //Elements 
        static By SignIn = By.XPath("//*[@id='myheader']/div[1]/header/div[2]/div[2]/div[4]/div/div/a[1]/span");

        internal static void takeScreenshot()
        { string path = @"C:\Users\sdetmindc193\source\repos\SpecFlowBigsMall\SpecFlowBigsMall\Screenshots";

           ((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(path + "\\Test" +count +".png", ScreenshotImageFormat.Png);
            count++;
        }

        static By custemail = By.Id("CustomerEmail");
        static By custpass = By.Id("CustomerPassword");
        static By clickSignIn = By.XPath("//*[@id='customer_login']/p[1]/input");

        static By searchBar = By.Name("q");
        static By product = By.XPath("//*[@id='snize-product-4001150992472']/a/div/span/span[1]");

        static By money = By.ClassName("money");
        static By item_Name = By.CssSelector("h1[class='h1 product-single__title']");
        static By Gift_Card = By.XPath("//span[text()='gift card']");

        static By postalcode = By.Id("PostalCode");
        static By COd = By.XPath("//*[@id='cod-cheker']/button");

        static By Avalbilty = By.Id("PostalCodeCheckerAvailability");

        static By WishList = By.XPath("//span[text()='wish list']");

        static By welcome = By.XPath("//*[@id='swym-welcome-button']");
        static By tab = By.XPath("//*[@id='swym-tabs-nav']/li[4]/a/i");
        static By email = By.XPath("//input[@type='email']");
        static By Connect = By.XPath("//*[@id='swym-email-auth-button']");
        static By Header = By.XPath("//*[@id='myheader']/div[1]/div/div/ul/li[8]/a");
        static By myheader = By.XPath("//*[@id='myheader']/div[1]/div/div/ul/li[8]/ul/li[4]/a");
        static By Solar = By.XPath("//*[@id='CollectionAjaxContent']/div[1]/div[1]/div/a/div[2]/div[1]");
        static By cart = By.XPath("//*[@id='AddToCartForm-4000780714072']/button");
        static By Rakhi = By.LinkText("Rakhi");
        static By more = By.XPath("//*[@id='more']");
        static By Top = By.XPath("//*[@id='myheader']/div[1]/div/div/ul/li[6]/a");

        static By Football = By.XPath("//*[@id='CollectionAjaxContent']/div[1]/div[23]/div/a/div[1]");
        static By wish = By.XPath("//*[@class='swym-wishlist-cta']");

        static By category = By.XPath("//*[@id='myheader']/div[1]/div/div/ul/li[9]/a");
        static By catButton = By.XPath("//*[@id='myheader']/div[1]/div/div/ul/li[9]/ul/li[13]/a");
        static By selectItem = (By.XPath("//*[@id='CollectionAjaxContent']/div[1]/div[20]/div/a/div[2]/div[1]"));

        static By money1 = By.ClassName("money");
        static By product1 = By.XPath("//*[@id='snize-product-2114990145624']/a/div/div/span/img[2]");

        static int count  =1;
        internal static void initializeBrowser()
        {
            //driver = new ChromeDriver(".");
            driver.Manage().Window.Maximize();
        }

        internal static void GoToUrl(string url)
        {
            driver.Navigate().GoToUrl(url);
        }

        internal static void close()
        {
            if (driver != null)
            {
                driver.Close();
                driver.Quit();
            }
        }

        internal static void ClickSignInButton()
        {
            driver.FindElement(SignIn).Click();
        }

        internal static void EnterDetails(string email, string pass)
        {

            driver.FindElement(custemail).SendKeys(email);
            driver.FindElement(custpass).SendKeys(pass);
            driver.FindElement(clickSignIn).Click();
        }

        internal static void Search(string item)
        {
            driver.FindElement(searchBar).SendKeys(item + Keys.Enter);
        }

        internal static void clickOngiftCard()
        {
            driver.FindElement(Gift_Card).Click();
        }

        internal static void checkCod()
        {
            string availabilty = driver.FindElement(Avalbilty).Text;
            Console.WriteLine(availabilty);
        }

        internal static void enterInBox(string _email)
        {
            driver.FindElement(email).SendKeys(_email);
        }

        internal static void addToCart()
        {
            driver.FindElement(cart).Click();
        }

        internal static void clickOnRakhi()
        {
            driver.FindElement(Rakhi).Click();
        }

        internal static void clickOnMore()
        {
            driver.FindElement(more).Click();
        }

        internal static void backToHome()
        {
            driver.Navigate().Back();
        }

        internal static void clickOnTop()
        {
            driver.FindElement(Top).Click();
        }

        internal static void clickonAddWishList()
        {
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20);
            driver.FindElement(wish).Click(); ;
        }

        internal static void VerifyProductprice(string expectedMoney)
        {
            string Actualmoney = driver.FindElement(money1).Text;
            Assert.AreEqual(expectedMoney, Actualmoney);
        }

        internal static void selectProductFromList()
        {
            driver.FindElement(product1).Click();
        }

        internal static void SelectandAddToCart()
        {
            driver.FindElement(selectItem).Click();

            Thread.Sleep(2000);
        }

        internal static void chooseCategory()
        {
            Actions mouse = new Actions(driver);
            mouse.MoveToElement(driver.FindElement(category)).Perform();

            driver.FindElement(catButton).Click();
        }

        internal static void clickOnFootball()
        {
            driver.FindElement(Football).Click();
        }

        internal static void clickOnSolar()
        {
            driver.FindElement(Solar).Click();
            Thread.Sleep(4000);
        }

        internal static void clickOnConnect()
        {
            driver.FindElement(Connect).Click();
        }

        internal static void Hover()
        {
            Actions action = new Actions(driver);

            action.MoveToElement(driver.FindElement(Header)).Perform();

            driver.FindElement(myheader).Click();
        }

        internal static void clickOnSettig()
        {
            Thread.Sleep(2000);
            driver.FindElement(welcome).Click();

            driver.FindElement(tab).Click();
        }

        internal static void clickOnWishList()
        {
            driver.FindElement(WishList).Click();
        }

        internal static void EnterPin(string pincode)
        {
            driver.FindElement(postalcode).SendKeys(pincode);
            driver.FindElement(COd).Click();
        }

        internal static void SelectProduct()
        {
            driver.FindElement(product).Click();
        }

        internal static void Verifyprice()
        {
            string price = driver.FindElement(money).Text;
            string item = driver.FindElement(item_Name).Text;
            Console.WriteLine("Name of the item : " + item);
            Console.WriteLine("The price of the item : " + price);
            Assert.AreEqual("Rs. 699", price);
        }
    }
}
