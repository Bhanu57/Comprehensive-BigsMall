﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;
using TechTalk.SpecFlow;

namespace SpecFlowBigsMall.Steps
{
    [Binding]
    public class TestingBigsmallSteps
    {
        IWebDriver driver = new ChromeDriver(".");

        [Given(@"Initialize browser with chrome")]
        public void GivenInitializeBrowserWithChrome()
        {
            BrowserFactory Pom = new BrowserFactory(driver);
            BrowserFactory.initializeBrowser();
        }

        [Given(@"Navigate to (.*) site")]
        public void GivenNavigateToSite(string url)
        {
            BrowserFactory.GoToUrl(url);

            Thread.Sleep(2000);
        }

        [Given(@"click on sign link in home page to land on secure sign in page")]
        public void GivenClickOnSignLinkInHomePageToLandOnSecureSignInPage()
        {
            BrowserFactory.ClickSignInButton();
        }

        [When(@"User enters (.*) and (.*) and sign in")]
        public void WhenUserEntersManisriGmail_ComAndAndSignIn(string email, string pass)
        {
            BrowserFactory.EnterDetails(email, pass);
        }

        [Given(@"Enter (.*) in search bar")]
        public void GivenEnterInSearchBar(string item)
        {
            BrowserFactory.Search(item);
        }

        [Then(@"Select first product in the list")]
        public void ThenSelectFirstProductInTheList()
        {
            BrowserFactory.SelectProduct();
        }


        [Then(@"Verify the product price")]
        public void ThenVerifyTheProductPrice()
        {
            BrowserFactory.Verifyprice();
        }

        [Given(@"Click on Gift Card")]
        public void GivenClickOnGiftCard()
        {
            BrowserFactory.clickOngiftCard();
        }

        [Then(@"Enter (.*)")]
        public void ThenEnter(string pincode)
        {
            BrowserFactory.EnterPin(pincode);
        }

        [Then(@"check the COD availability")]
        public void ThenCheckTheCODAvailability()
        {
            BrowserFactory.checkCod();
        }

        [Given(@"Click on wish list")]
        public void GivenClickOnWishList()
        {
            BrowserFactory.clickOnWishList();
        }

        [Given(@"Click on setting")]
        public void GivenClickOnSetting()
        {
            BrowserFactory.clickOnSettig();
        }

        [Then(@"Entered (.*) in the box")]
        public void ThenEnterdInTheBox(string email)
        {
            BrowserFactory.enterInBox(email);
        }

        [Then(@"Click on connect")]
        public void ThenClickOnConnect()
        {
            BrowserFactory.clickOnConnect();
        }

        [Given(@"Hover at official merchandise and click on Marvel")]
        public void GivenHoverAtOfficialMerchandiseAndClickOnMarvel()
        {
            BrowserFactory.Hover();
        }

        [Then(@"click on iron man solar")]
        public void ThenClickOnIronManSolar()
        {
            BrowserFactory.clickOnSolar();
        }

        [Then(@"Click on add to cart")]
        public void ThenClickOnAddToCart()
        {
            BrowserFactory.addToCart();
        }

        [Given(@"click on Rakhi")]
        public void GivenClickOnRakhi()
        {
            BrowserFactory.clickOnRakhi();
        }

        [Then(@"click on Readmore")]
        public void ThenClickOnReadmore()
        {
            BrowserFactory.clickOnMore();
        }

        [Then(@"Navigate to homepage")]
        public void ThenNavigateToHomepage()
        {
            BrowserFactory.backToHome();
        }

        [Then(@"click on top50")]
        public void ThenClickOnTop()
        {
            BrowserFactory.clickOnTop();
        }

        [Then(@"click on footbal shoe mug")]
        public void ThenClickOnFootbalShoeMug()
        {
            BrowserFactory.clickOnFootball();
        }

        [Then(@"click on Add wishlist")]
        public void ThenClickOnAddWishlist()
        {
            BrowserFactory.clickonAddWishList();
        }

        [Then(@"Choose ShopbyCategory and click Travel Acccessories")]
        public void ThenChooseShopbyCategoryAndClickTravelAcccessories()
        {
            BrowserFactory.chooseCategory();
        }

        [Then(@"select key chain from menu")]
        public void ThenSelectKeyChainAndAddToCart()
        {
            BrowserFactory.SelectandAddToCart();
        }

        [Then(@"Verify the product price is (.*)")]
        public void ThenVerifyTheProductPriceIsRs_(string expectedMoney)
        {
            BrowserFactory.VerifyProductprice(expectedMoney);
        }


        [Then(@"Select product in the list")]
        public void ThenSelectProductInTheList()
        {
            BrowserFactory.selectProductFromList();
        }
    }
}


